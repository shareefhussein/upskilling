from django.db import models

class Books(models.Model):
    bookname = models.CharField(max_length=25)
    isbn = models.IntegerField(null=True, blank=True)
    STATUS = (
         ('available', 'AVAILABLE'),
         ('unavailable', 'UNAVAILABLE')
    )
    book_status = models.CharField(max_length= 30, default= 'available', null= False)
    
    def __str__(self):
        return self.bookname

class Students(models.Model):
    student_firstname= models.CharField(max_length=25)
    student_lastname= models.CharField(max_length=25) 

    def __str__(self):
        return self.student_firstname
        
class Borrow(models.Model):
    students_names = models.ForeignKey(to ='Students',on_delete=models.PROTECT)
    books_names = models.ForeignKey(to ='Books',on_delete=models.PROTECT)
    STATUS = (
         ('available', 'AVAILABLE'),
         ('unavailable', 'UNAVAILABLE')
    )
    book_status = models.CharField(max_length= 30, default= 'unavailable', null= False)

    def __str__(self):
            return self.students_names.student_firstname
    
        