from django.contrib import admin
from mainapp.models import Books, Students, Borrow


# Register your models here.

admin.site.register(Books)
admin.site.register(Students)
admin.site.register(Borrow)
