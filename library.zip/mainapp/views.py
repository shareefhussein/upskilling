from django.shortcuts import render,  HttpResponse
from mainapp.models import Books, Students, Borrow
from mainapp.forms import BooksForm, StudentForm, BorrowForm

def main_view(request):
    return HttpResponse('Enter /bookpage after url to show the book page')

def book_view(request):
    var = {}
    if request.method == 'POST':
        form = BooksForm(request.POST)
        if form.is_valid():
           form.save()
           return render (request,'books.html', context= var)
    else:
        var['book']= Books.objects.all()
        var['form']=BooksForm()
        return render (request,'books.html',context = var)


def student_view(request):
    var2 = {}
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            return render (request,'students.html', context= var2)
    else:
        var2['student']= Students.objects.all()
        var2['form']= StudentForm()
        return render (request,'students.html',context = var2)


def borrow_view(request):
    var3 = {}
    if request.method == 'POST':
        form = BorrowForm(request.POST)
        if form.is_valid():
           form.save()
           return render (request,'borrow.html', context= var3)  
    else:
        var3['borrow']= Borrow.objects.all()
        var3['form']= BorrowForm()
        return render (request,'borrow.html',context= var3) 

def base_view(request):
    return render(request,"base.html")
