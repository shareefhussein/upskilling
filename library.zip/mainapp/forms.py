from django import forms
from django.forms.models import ModelForm
from mainapp.models import Books, Students, Borrow

class BooksForm(ModelForm):
    class Meta:
        model = Books
        exclude = []

class StudentForm(ModelForm):
    class Meta:
        model = Students
        exclude = [] 

class BorrowForm(ModelForm):
    class Meta:
        model = Borrow
        exclude = [] 


