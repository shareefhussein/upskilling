from django.contrib import admin
from mainapp.models import Books, User, Res

# Register your models here.
admin.site.register(Books)
admin.site.register(User)
admin.site.register(Res)

