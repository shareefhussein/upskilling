import os
from django.shortcuts import render,  HttpResponse
from mainapp.models import Books, User, Res
from mainapp.forms import BooksForm, UserForm, ResForm

# Create your views here.
def main_view(request):
    return HttpResponse('main page')

def Book_main(request):
    if request.method == 'POST':
        form = BooksForm(request.POST)
        variables = {}
        if form.is_valid():
            new_book = Books()
            new_book.bookname = form.cleaned_data['bookname']
            new_book.ispn = form.cleaned_data['ispn']
            new_book.save()
        return render (request,'books.html',context = variables)

    else:
        variables = {}
        variables['user']= Books.objects.all()
        variables['form']=BooksForm()
        return render (request,'books.html',context = variables)

def User_main(request):
    if request.method == 'POST':
        form = UserForm(request.POST)
        variables = {}
        if form.is_valid():
            new_user = User()
            new_user.username = form.cleaned_data['username']
            new_user.save()
        return render (request,'user.html',context = variables)

    else:
        variables = {}
        variables['user']=User.objects.all()
        variables['form']=UserForm()
        return render (request,'user.html',context = variables)    

def Res_main(request):
    if request.method == 'POST':
        form = ResForm(request.POST)
        variables = {}
        if form.is_valid():
            new_res = Res()
            new_res.book = form.cleaned_data['bookname']
            new_res.name = form.cleaned_data['username']
            new_res.save()
        return render (request,'reserve.html',context = variables)
    else:
        variables = {}
        variables['user']=Res.objects.all()
        variables['form']=ResForm()
        return render (request,'reserve.html',context = variables)           






