from django.db import models


# Create your models here.
class Books(models.Model):
    bookname = models.CharField(max_length=25)
    ispn = models.IntegerField(null=True, blank=True)
    def __str__(self):
        return self.bookname

class User(models.Model):
    username= models.CharField(max_length=25) 
    def __str__(self):
        return self.username


class Res(models.Model):
    book = models.CharField(max_length=25)
    name= models.CharField(max_length=25)
    def __str__(self):
        return self.name
    # bookname = models.ForeignKey(to ='Books',on_delete=models.PROTECT) 
    # username = models.ForeignKey(to = 'User',on_delete=models.PROTECT)
    
