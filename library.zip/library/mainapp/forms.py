from django import forms
class BooksForm(forms.Form):
    bookname = forms.CharField(label= 'book name',max_length=25)
    ispn = forms.IntegerField(label = 'ispn')

class UserForm(forms.Form):
    username = forms.CharField(label= 'user name',max_length=25)

class ResForm(forms.Form):
    bookname = forms.CharField(label= 'book name',max_length=25)
    username = forms.CharField(label= 'user name',max_length=25)



